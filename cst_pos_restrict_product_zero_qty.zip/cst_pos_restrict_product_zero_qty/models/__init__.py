# -*- coding: utf-8 -*-

from . import pos_fields
from . import product_product
